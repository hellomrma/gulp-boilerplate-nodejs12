;(function (win, $) {
    'use strict';



    $(function () {

    });

    $(win).on('load', function () {

    });
})(window, window.jQuery);